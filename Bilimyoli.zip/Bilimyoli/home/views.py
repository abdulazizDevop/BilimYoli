from django.shortcuts import render
from django.http import HttpResponseRedirect

def index(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def course(request):
    return render(request, 'courses.html')

def contact(request):
    return render(request, 'contacts.html')